import os
from dotenv import load_dotenv
from openai import OpenAI
from utils.token_counter import estimate_tokens
from utils.model_selector import select_model

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", 300))

LOG_FILE = "logs/failed_pipeline.log"
IMPORTANT_KEYWORDS = ["ERROR", "FAILED", "EXCEPTION", "Traceback"]

def filter_logs(log_file):
    filtered = []
    with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if any(word in line for word in IMPORTANT_KEYWORDS):
                filtered.append(line.strip())
    return "\n".join(filtered[:200])

def analyze_logs():
    print("Reading CI/CD logs...")
    logs = filter_logs(LOG_FILE)

    tokens = estimate_tokens(logs)
    print(f"Estimated Tokens: {tokens}")

    if tokens > 800:
        print("Token usage too high. Aborting OpenAI call.")
        return

    model = select_model("analysis")
    print(f"Using Model: {model}")

    response = client.chat.completions.create(
        model=model,
        max_completion_tokens=MAX_TOKENS,
        messages=[
            {
                "role": "system",
                "content": "You are a senior DevOps engineer. Analyze CI/CD pipeline failures."
            },
            {
                "role": "user",
                "content": f"""
Analyze the CI/CD logs and provide:
1. Root Cause
2. Impact
3. Suggested Fix

Logs:
{logs}
"""
            }
        ]
    )

    print("\nAI ANALYSIS RESULT:\n")
    print(response.choices[0].message.content)

if __name__ == "__main__":
    analyze_logs()

