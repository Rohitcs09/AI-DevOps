def select_model(task_type):
    if task_type == "summary":
        return "gpt-5-nano"
    if task_type == "analysis":
        return "gpt-5-mini"
    return "gpt-5.2"

