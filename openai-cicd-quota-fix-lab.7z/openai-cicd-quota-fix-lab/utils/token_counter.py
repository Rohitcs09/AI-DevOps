import tiktoken

def estimate_tokens(text, model="gpt-5-mini"):
    encoding = tiktoken.get_encoding("cl100k_base")
    return len(encoding.encode(text))

